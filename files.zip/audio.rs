use anyhow::{Context, Result};
use cpal::traits::{DeviceTrait, HostTrait, StreamTrait};
use cpal::{Device, SampleFormat, SampleRate, StreamConfig};
use crossbeam_channel::Sender;
use std::sync::{Arc, Mutex, atomic::{AtomicBool, Ordering}};
use tracing::{debug, info, warn};

use crate::config::Config;
use crate::vad::{Vad, VadEvent};

const WHISPER_SAMPLE_RATE: u32 = 16000;

pub struct AudioCapture {
    device: Device,
    config: Config,
}

impl AudioCapture {
    pub fn new(config: &Config) -> Result<Self> {
        let host = cpal::default_host();

        let device = if let Some(name) = &config.device_name {
            host.input_devices()?
                .find(|d| d.name().map(|n| n.contains(name.as_str())).unwrap_or(false))
                .with_context(|| format!("Audio device '{}' not found", name))?
        } else {
            host.default_input_device()
                .context("No default input device found")?
        };

        info!("Audio device: {}", device.name().unwrap_or_default());
        Ok(Self {
            device,
            config: config.clone(),
        })
    }

    pub fn run(
        &self,
        audio_tx: Sender<Vec<f32>>,
        running: Arc<AtomicBool>,
    ) -> Result<()> {
        // Prefer 16kHz mono, fall back to device default and resample
        let stream_config = self.best_config()?;
        let actual_rate = stream_config.sample_rate.0;
        info!(
            "Stream: {}Hz, {} ch, {:?}",
            actual_rate,
            stream_config.channels,
            stream_config.buffer_size
        );

        // Shared buffer for accumulating samples
        let buffer: Arc<Mutex<Vec<f32>>> = Arc::new(Mutex::new(Vec::new()));
        let buffer_w = buffer.clone();

        let vad_cfg = self.config.clone();
        let audio_tx_inner = audio_tx.clone();

        // VAD state lives in the audio callback closure
        let vad = Arc::new(Mutex::new(Vad::new(
            vad_cfg.vad_threshold,
            WHISPER_SAMPLE_RATE,
            vad_cfg.silence_threshold_ms,
            vad_cfg.min_speech_ms,
        )));
        let vad_clone = vad.clone();

        let channels = stream_config.channels as usize;
        let needs_resample = actual_rate != WHISPER_SAMPLE_RATE;
        let resample_ratio = WHISPER_SAMPLE_RATE as f64 / actual_rate as f64;

        // Per-segment accumulator (speech samples at 16kHz)
        let segment: Arc<Mutex<Vec<f32>>> = Arc::new(Mutex::new(Vec::new()));
        let segment_w = segment.clone();

        let max_samples = (vad_cfg.max_buffer_secs * WHISPER_SAMPLE_RATE as f32) as usize;

        let err_fn = |err| warn!("Audio stream error: {}", err);

        let stream = match self.device.default_input_config()?.sample_format() {
            SampleFormat::F32 => self.device.build_input_stream(
                &stream_config,
                move |data: &[f32], _| {
                    handle_audio_f32(
                        data,
                        channels,
                        actual_rate,
                        needs_resample,
                        resample_ratio,
                        &segment_w,
                        &vad_clone,
                        &audio_tx_inner,
                        max_samples,
                    );
                },
                err_fn,
                None,
            )?,
            SampleFormat::I16 => self.device.build_input_stream(
                &stream_config,
                move |data: &[i16], _| {
                    let f32_data: Vec<f32> = data.iter().map(|&s| s as f32 / 32768.0).collect();
                    handle_audio_f32(
                        &f32_data,
                        channels,
                        actual_rate,
                        needs_resample,
                        resample_ratio,
                        &segment_w,
                        &vad_clone,
                        &audio_tx_inner,
                        max_samples,
                    );
                },
                err_fn,
                None,
            )?,
            fmt => anyhow::bail!("Unsupported sample format: {:?}", fmt),
        };

        stream.play()?;
        info!("Recording started. Speak now...");

        // Block until Ctrl+C
        while running.load(Ordering::SeqCst) {
            std::thread::sleep(std::time::Duration::from_millis(100));
        }

        Ok(())
    }

    fn best_config(&self) -> Result<StreamConfig> {
        // Try 16kHz mono first (ideal for Whisper)
        let desired = StreamConfig {
            channels: 1,
            sample_rate: SampleRate(WHISPER_SAMPLE_RATE),
            buffer_size: cpal::BufferSize::Default,
        };

        if let Ok(supported) = self.device.default_input_config() {
            // Use device default config but we handle conversion ourselves
            Ok(supported.config())
        } else {
            Ok(desired)
        }
    }
}

fn handle_audio_f32(
    data: &[f32],
    channels: usize,
    actual_rate: u32,
    needs_resample: bool,
    resample_ratio: f64,
    segment: &Arc<Mutex<Vec<f32>>>,
    vad: &Arc<Mutex<Vad>>,
    tx: &Sender<Vec<f32>>,
    max_samples: usize,
) {
    // Step 1: Downmix to mono
    let mono: Vec<f32> = if channels == 1 {
        data.to_vec()
    } else {
        data.chunks(channels)
            .map(|frame| frame.iter().sum::<f32>() / channels as f32)
            .collect()
    };

    // Step 2: Resample to 16kHz if needed
    let resampled: Vec<f32> = if needs_resample {
        linear_resample(&mono, resample_ratio)
    } else {
        mono
    };

    // Step 3: VAD + accumulate
    let event = vad.lock().unwrap().process(&resampled);
    let mut seg = segment.lock().unwrap();

    match event {
        VadEvent::SpeechStart | VadEvent::None => {
            if vad.lock().unwrap().is_speaking {
                seg.extend_from_slice(&resampled);
                // Hard cap to prevent unbounded growth
                if seg.len() > max_samples {
                    let drain_to = seg.len() - max_samples;
                    seg.drain(..drain_to);
                }
            }
        }
        VadEvent::SpeechEnd => {
            seg.extend_from_slice(&resampled);
            let samples = seg.clone();
            seg.clear();
            debug!("Speech segment: {} samples ({:.1}s)", samples.len(), samples.len() as f32 / 16000.0);
            let _ = tx.send(samples);
        }
        VadEvent::SpeechTooShort => {
            seg.clear();
            debug!("Speech too short, discarding");
        }
    }
}

/// Linear interpolation resampling
fn linear_resample(samples: &[f32], ratio: f64) -> Vec<f32> {
    if samples.is_empty() {
        return vec![];
    }
    let new_len = ((samples.len() as f64) * ratio).round() as usize;
    let mut out = Vec::with_capacity(new_len);
    for i in 0..new_len {
        let src_pos = i as f64 / ratio;
        let src_idx = src_pos as usize;
        let frac = src_pos - src_idx as f64;
        let s0 = samples[src_idx.min(samples.len() - 1)];
        let s1 = samples[(src_idx + 1).min(samples.len() - 1)];
        out.push(s0 + (s1 - s0) * frac as f32);
    }
    out
}

/// List available audio input devices
pub fn list_devices() -> Result<()> {
    let host = cpal::default_host();
    println!("Available input devices:");
    for (i, device) in host.input_devices()?.enumerate() {
        let name = device.name().unwrap_or_else(|_| "Unknown".to_string());
        let default = host.default_input_device()
            .and_then(|d| d.name().ok())
            .map(|dn| dn == name)
            .unwrap_or(false);
        println!("  [{}] {}{}", i, name, if default { " (default)" } else { "" });
    }
    Ok(())
}
