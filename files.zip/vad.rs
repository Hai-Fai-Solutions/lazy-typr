/// Simple energy-based Voice Activity Detection
pub struct Vad {
    threshold: f32,
    sample_rate: u32,
    silence_threshold_samples: usize,
    min_speech_samples: usize,

    // State
    silence_counter: usize,
    speech_counter: usize,
    pub is_speaking: bool,
}

impl Vad {
    pub fn new(
        threshold: f32,
        sample_rate: u32,
        silence_threshold_ms: u64,
        min_speech_ms: u64,
    ) -> Self {
        let silence_threshold_samples =
            (sample_rate as u64 * silence_threshold_ms / 1000) as usize;
        let min_speech_samples =
            (sample_rate as u64 * min_speech_ms / 1000) as usize;

        Self {
            threshold,
            sample_rate,
            silence_threshold_samples,
            min_speech_samples,
            silence_counter: 0,
            speech_counter: 0,
            is_speaking: false,
        }
    }

    /// Process a chunk of samples. Returns true if a speech segment just ended
    /// and samples should be sent for transcription.
    pub fn process(&mut self, samples: &[f32]) -> VadEvent {
        let energy = rms_energy(samples);
        let is_voice = energy > self.threshold;

        if is_voice {
            self.silence_counter = 0;
            self.speech_counter += samples.len();
            if !self.is_speaking {
                self.is_speaking = true;
                return VadEvent::SpeechStart;
            }
        } else {
            if self.is_speaking {
                self.silence_counter += samples.len();
                if self.silence_counter >= self.silence_threshold_samples {
                    self.is_speaking = false;
                    let had_enough_speech = self.speech_counter >= self.min_speech_samples;
                    self.speech_counter = 0;
                    self.silence_counter = 0;
                    if had_enough_speech {
                        return VadEvent::SpeechEnd;
                    } else {
                        return VadEvent::SpeechTooShort;
                    }
                }
            }
        }

        VadEvent::None
    }

    pub fn reset(&mut self) {
        self.silence_counter = 0;
        self.speech_counter = 0;
        self.is_speaking = false;
    }
}

#[derive(Debug, PartialEq)]
pub enum VadEvent {
    None,
    SpeechStart,
    SpeechEnd,
    SpeechTooShort,
}

fn rms_energy(samples: &[f32]) -> f32 {
    if samples.is_empty() {
        return 0.0;
    }
    let sum: f32 = samples.iter().map(|s| s * s).sum();
    (sum / samples.len() as f32).sqrt()
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_vad_silence() {
        let mut vad = Vad::new(0.01, 16000, 500, 200);
        let silence = vec![0.0f32; 1600]; // 100ms silence
        assert_eq!(vad.process(&silence), VadEvent::None);
    }

    #[test]
    fn test_vad_speech_detection() {
        let mut vad = Vad::new(0.01, 16000, 500, 200);
        let speech: Vec<f32> = (0..3200).map(|i| (i as f32 * 0.1).sin() * 0.5).collect();
        let event = vad.process(&speech);
        assert_eq!(event, VadEvent::SpeechStart);
    }
}
