# whisper-type 🎤

Echtzeit Speech-to-Text für Linux — transkribiert deine Sprache lokal mit OpenAI Whisper und tippt den Text direkt in das aktive Eingabefeld.

**Keine Cloud. Keine API-Keys. Vollständig offline.**

---

## Features

- 🎙️ **Echtzeit-Aufnahme** via CPAL (ALSA/PulseAudio/Pipewire)
- 🧠 **Lokale KI** via Whisper (ggml, kein Internet nötig)
- ⌨️ **Automatisches Tippen** in jedes fokussierte Textfeld (xdotool)
- 🔇 **Voice Activity Detection** — sendet nur wenn du wirklich sprichst
- 🌍 **Mehrsprachig** — Deutsch, Englisch, und alle anderen Whisper-Sprachen
- ⚡ **Multi-threaded** — Audio, VAD, Whisper und Typer laufen parallel

---

## Schnellstart

```bash
# 1. Setup (einmalig)
chmod +x setup.sh
./setup.sh

# 2. Starten
whisper-type

# 3. Sprechen — Text erscheint im aktiven Fenster
```

---

## Installation (manuell)

### System-Abhängigkeiten

```bash
sudo apt install xdotool libasound2-dev pkg-config build-essential xclip
```

### Whisper Model herunterladen

```bash
mkdir -p ~/.local/share/whisper-type
wget https://huggingface.co/ggerganov/whisper.cpp/resolve/main/ggml-base.bin \
     -O ~/.local/share/whisper-type/ggml-base.bin
```

| Modell | Größe | Qualität | RAM |
|--------|-------|----------|-----|
| tiny   | 75 MB | ⭐⭐ | ~1 GB |
| **base** | **142 MB** | **⭐⭐⭐** | **~1 GB** |
| small  | 466 MB | ⭐⭐⭐⭐ | ~2 GB |
| medium | 1.5 GB | ⭐⭐⭐⭐⭐ | ~5 GB |

### Build

```bash
cargo build --release
cp target/release/whisper-type ~/.local/bin/
```

---

## Verwendung

```
USAGE:
    whisper-type [OPTIONS]

OPTIONS:
    -m, --model <PATH>        Pfad zur GGML-Modelldatei
    -d, --device <NAME>       Audio-Eingabegerät (Standard: System-Default)
    -l, --language <LANG>     Sprache (de, en, fr, ...) [Standard: de]
        --silence-ms <MS>     Stille-Schwelle in ms [Standard: 800]
        --list-devices        Verfügbare Audio-Geräte anzeigen
        --dry-run             Text auf stdout ausgeben statt zu tippen
    -h, --help                Hilfe anzeigen
```

### Beispiele

```bash
# Deutsch (Standard)
whisper-type

# Englisch
whisper-type --language en

# Anderes Mikrofon
whisper-type --list-devices
whisper-type --device "USB Audio"

# Schnellere Reaktion (500ms Pause reicht)
whisper-type --silence-ms 500

# Testen ohne zu tippen
whisper-type --dry-run

# Größeres Modell für bessere Genauigkeit
whisper-type --model ~/.local/share/whisper-type/ggml-small.bin
```

---

## Konfiguration

Gespeichert unter `~/.config/whisper-type/config.json`:

```json
{
  "model_path": "/home/user/.local/share/whisper-type/ggml-base.bin",
  "device_name": null,
  "language": "de",
  "silence_threshold_ms": 800,
  "min_speech_ms": 300,
  "max_buffer_secs": 30.0,
  "vad_threshold": 0.01
}
```

| Parameter | Beschreibung |
|-----------|-------------|
| `silence_threshold_ms` | Wie lange Stille, bis Segment gesendet wird |
| `min_speech_ms` | Minimale Sprachzeit, sonst verworfen |
| `vad_threshold` | Energie-Schwelle für Spracherkennung (0.0–1.0) |
| `max_buffer_secs` | Maximale Aufnahmedauer pro Segment |

---

## Wie es funktioniert

```
Mikrofon (CPAL)
     │
     ▼
Downmix → Mono
     │
     ▼
Resampling → 16kHz
     │
     ▼
VAD (Energy-based)
     │  speech end detected
     ▼
Whisper (ggml, lokal)
     │
     ▼
Text-Filter (Halluzinationen)
     │
     ▼
xdotool type → aktives Fenster
```

---

## Fehlerbehebung

**`xdotool not found`**
```bash
sudo apt install xdotool
```

**`No default input device found`**
```bash
# PulseAudio/Pipewire prüfen
pactl list sources short
whisper-type --list-devices
```

**Text wird nicht getippt (Wayland)**  
Wayland unterstützt `xdotool` nicht direkt. Lösungen:
- Wechsel zu XWayland-Modus
- Oder `ydotool` installieren (erfordert Kernel-Modul)

**Whisper-Modell nicht gefunden**  
```bash
# Standardpfad:
ls ~/.local/share/whisper-type/
# Oder explizit angeben:
whisper-type --model /pfad/zum/modell.bin
```

**Zu viele Halluzinationen bei Stille**  
```bash
# VAD-Schwelle erhöhen
# In ~/.config/whisper-type/config.json:
"vad_threshold": 0.02
```

---

## Lizenz

MIT
