mod audio;
mod config;
mod transcriber;
mod typer;
mod vad;

use anyhow::Result;
use clap::Parser;
use crossbeam_channel::{bounded, unbounded};
use std::sync::{Arc, atomic::{AtomicBool, Ordering}};
use tracing::{info, error};

use config::Config;
use audio::AudioCapture;
use transcriber::Transcriber;
use typer::Typer;

#[derive(Parser, Debug)]
#[command(name = "whisper-type")]
#[command(about = "Real-time speech-to-text that types into focused input fields")]
struct Args {
    /// Path to Whisper GGML model file
    #[arg(short, long)]
    model: Option<std::path::PathBuf>,

    /// Audio input device (default: system default)
    #[arg(short, long)]
    device: Option<String>,

    /// Whisper language (e.g. "de", "en", auto-detect if not set)
    #[arg(short, long, default_value = "de")]
    language: String,

    /// Show available audio devices and exit
    #[arg(long)]
    list_devices: bool,

    /// VAD silence threshold in milliseconds
    #[arg(long, default_value = "800")]
    silence_ms: u64,

    /// Push-to-talk mode: hold key to record (e.g. "ctrl+space")
    #[arg(long)]
    ptt_key: Option<String>,

    /// Print transcribed text to stdout instead of typing it
    #[arg(long)]
    dry_run: bool,
}

fn main() -> Result<()> {
    // Initialize logging
    tracing_subscriber::fmt()
        .with_env_filter(
            tracing_subscriber::EnvFilter::from_default_env()
                .add_directive("whisper_type=info".parse()?)
        )
        .init();

    let args = Args::parse();

    // List devices mode
    if args.list_devices {
        audio::list_devices()?;
        return Ok(());
    }

    // Load config (merge with CLI args)
    let mut config = Config::load_or_default()?;
    if let Some(model) = args.model {
        config.model_path = model;
    }
    if let Some(device) = args.device {
        config.device_name = Some(device);
    }
    config.language = args.language;
    config.silence_threshold_ms = args.silence_ms;
    config.dry_run = args.dry_run;

    // Validate model path
    if !config.model_path.exists() {
        error!(
            "Whisper model not found at: {}\n\
             Download a model with:\n\
             wget https://huggingface.co/ggerganov/whisper.cpp/resolve/main/ggml-base.bin \\\n\
             -O ~/.local/share/whisper-type/ggml-base.bin",
            config.model_path.display()
        );
        std::process::exit(1);
    }

    info!("whisper-type starting...");
    info!("Model: {}", config.model_path.display());
    info!("Language: {}", config.language);
    info!("Silence threshold: {}ms", config.silence_threshold_ms);
    if config.dry_run {
        info!("Dry-run mode: text will be printed to stdout");
    }

    // Shared running flag
    let running = Arc::new(AtomicBool::new(true));
    let r = running.clone();

    // Handle Ctrl+C
    ctrlc::set_handler(move || {
        info!("Shutting down...");
        r.store(false, Ordering::SeqCst);
    }).ok();

    // Channel: audio chunks (PCM f32 mono 16kHz) → transcriber
    let (audio_tx, audio_rx) = bounded::<Vec<f32>>(32);

    // Channel: transcribed text → typer
    let (text_tx, text_rx) = unbounded::<String>();

    // Start transcriber thread
    let config_t = config.clone();
    let text_tx_t = text_tx.clone();
    let transcriber_handle = std::thread::spawn(move || {
        let mut transcriber = match Transcriber::new(&config_t) {
            Ok(t) => t,
            Err(e) => {
                error!("Failed to initialize Whisper: {}", e);
                std::process::exit(1);
            }
        };
        info!("Whisper model loaded ✓");
        loop {
            match audio_rx.recv() {
                Ok(samples) => {
                    match transcriber.transcribe(&samples) {
                        Ok(Some(text)) => {
                            let text = text.trim().to_string();
                            if !text.is_empty() {
                                info!("Transcribed: \"{}\"", text);
                                let _ = text_tx_t.send(text);
                            }
                        }
                        Ok(None) => {}
                        Err(e) => error!("Transcription error: {}", e),
                    }
                }
                Err(_) => break, // channel closed
            }
        }
    });

    // Start typer thread
    let config_ty = config.clone();
    let typer_handle = std::thread::spawn(move || {
        let typer = Typer::new(config_ty.dry_run);
        loop {
            match text_rx.recv() {
                Ok(text) => {
                    if let Err(e) = typer.type_text(&text) {
                        error!("Failed to type text: {}", e);
                    }
                }
                Err(_) => break,
            }
        }
    });

    // Start audio capture (blocks until running=false)
    info!("Microphone active — speak to transcribe. Ctrl+C to quit.");
    let capture = AudioCapture::new(&config)?;
    capture.run(audio_tx, running)?;

    info!("Stopping...");
    // Channels will be dropped, threads will exit
    drop(capture);
    let _ = transcriber_handle.join();
    let _ = typer_handle.join();

    Ok(())
}
