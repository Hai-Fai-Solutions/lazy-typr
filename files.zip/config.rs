use anyhow::Result;
use serde::{Deserialize, Serialize};
use std::path::PathBuf;

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Config {
    /// Path to the Whisper GGML model
    pub model_path: PathBuf,

    /// Optional audio device name
    pub device_name: Option<String>,

    /// Whisper language code ("de", "en", etc.)
    pub language: String,

    /// Milliseconds of silence before a speech segment is finalized
    pub silence_threshold_ms: u64,

    /// Minimum speech duration in ms to trigger transcription
    pub min_speech_ms: u64,

    /// Maximum recording buffer in seconds
    pub max_buffer_secs: f32,

    /// Energy threshold for voice activity detection (0.0 - 1.0)
    pub vad_threshold: f32,

    /// Print to stdout instead of typing
    #[serde(skip)]
    pub dry_run: bool,
}

impl Default for Config {
    fn default() -> Self {
        let model_path = dirs::data_local_dir()
            .unwrap_or_else(|| PathBuf::from("."))
            .join("whisper-type")
            .join("ggml-base.bin");

        Self {
            model_path,
            device_name: None,
            language: "de".to_string(),
            silence_threshold_ms: 800,
            min_speech_ms: 300,
            max_buffer_secs: 30.0,
            vad_threshold: 0.01,
            dry_run: false,
        }
    }
}

impl Config {
    pub fn config_path() -> PathBuf {
        dirs::config_dir()
            .unwrap_or_else(|| PathBuf::from("."))
            .join("whisper-type")
            .join("config.json")
    }

    pub fn load_or_default() -> Result<Self> {
        let path = Self::config_path();
        if path.exists() {
            let content = std::fs::read_to_string(&path)?;
            let config: Config = serde_json::from_str(&content)?;
            tracing::info!("Loaded config from {}", path.display());
            Ok(config)
        } else {
            Ok(Config::default())
        }
    }

    pub fn save(&self) -> Result<()> {
        let path = Self::config_path();
        if let Some(parent) = path.parent() {
            std::fs::create_dir_all(parent)?;
        }
        let content = serde_json::to_string_pretty(self)?;
        std::fs::write(&path, content)?;
        tracing::info!("Saved config to {}", path.display());
        Ok(())
    }
}
