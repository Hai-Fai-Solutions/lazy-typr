use anyhow::{Context, Result};
use tracing::{debug, info};

pub struct Typer {
    dry_run: bool,
}

impl Typer {
    pub fn new(dry_run: bool) -> Self {
        Self { dry_run }
    }

    /// Type the given text into the currently focused window.
    ///
    /// Strategy:
    /// 1. Use xdotool to type the text (handles Unicode well)
    /// 2. Fall back to xclip + Ctrl+Shift+V if xdotool fails
    pub fn type_text(&self, text: &str) -> Result<()> {
        if self.dry_run {
            println!("{}", text);
            return Ok(());
        }

        // Add a trailing space so the next word doesn't merge
        let text_with_space = format!("{} ", text);

        debug!("Typing: {:?}", text_with_space);

        // Primary method: xdotool type
        if self.type_with_xdotool(&text_with_space).is_ok() {
            return Ok(());
        }

        // Fallback: clipboard paste
        info!("xdotool failed, falling back to clipboard paste");
        self.type_with_clipboard(&text_with_space)
    }

    fn type_with_xdotool(&self, text: &str) -> Result<()> {
        // --clearmodifiers: release Shift/Ctrl/etc. before typing
        // --delay 0: no inter-key delay (faster)
        let output = std::process::Command::new("xdotool")
            .args([
                "type",
                "--clearmodifiers",
                "--delay", "0",
                "--",
                text,
            ])
            .output()
            .context("xdotool not found. Install with: sudo apt install xdotool")?;

        if output.status.success() {
            Ok(())
        } else {
            let stderr = String::from_utf8_lossy(&output.stderr);
            anyhow::bail!("xdotool failed: {}", stderr)
        }
    }

    fn type_with_clipboard(&self, text: &str) -> Result<()> {
        // Save current clipboard
        let saved = self.get_clipboard();

        // Set clipboard to our text
        self.set_clipboard(text)?;

        // Small delay to let clipboard settle
        std::thread::sleep(std::time::Duration::from_millis(50));

        // Paste using Ctrl+V (or Ctrl+Shift+V for terminals)
        let paste_result = std::process::Command::new("xdotool")
            .args(["key", "--clearmodifiers", "ctrl+v"])
            .status();

        // Restore clipboard
        if let Ok(saved_text) = saved {
            std::thread::sleep(std::time::Duration::from_millis(100));
            let _ = self.set_clipboard(&saved_text);
        }

        paste_result
            .context("xdotool key failed")?
            .success()
            .then_some(())
            .ok_or_else(|| anyhow::anyhow!("xdotool key ctrl+v failed"))
    }

    fn set_clipboard(&self, text: &str) -> Result<()> {
        // Try xclip first, then xsel
        let r = std::process::Command::new("xclip")
            .args(["-selection", "clipboard"])
            .stdin(std::process::Stdio::piped())
            .spawn();

        if let Ok(mut child) = r {
            use std::io::Write;
            if let Some(stdin) = child.stdin.as_mut() {
                stdin.write_all(text.as_bytes())?;
            }
            child.wait()?;
            return Ok(());
        }

        // Try xsel
        let r = std::process::Command::new("xsel")
            .args(["--clipboard", "--input"])
            .stdin(std::process::Stdio::piped())
            .spawn();

        if let Ok(mut child) = r {
            use std::io::Write;
            if let Some(stdin) = child.stdin.as_mut() {
                stdin.write_all(text.as_bytes())?;
            }
            child.wait()?;
            return Ok(());
        }

        // Try arboard (pure Rust, X11)
        let mut clipboard = arboard::Clipboard::new()
            .context("Failed to open clipboard")?;
        clipboard.set_text(text)
            .context("Failed to set clipboard text")?;
        Ok(())
    }

    fn get_clipboard(&self) -> Result<String> {
        let mut clipboard = arboard::Clipboard::new()?;
        Ok(clipboard.get_text().unwrap_or_default())
    }
}
