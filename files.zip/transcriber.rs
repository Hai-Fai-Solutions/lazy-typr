use anyhow::{Context, Result};
use whisper_rs::{FullParams, SamplingStrategy, WhisperContext, WhisperContextParameters};
use tracing::debug;

use crate::config::Config;

pub struct Transcriber {
    ctx: WhisperContext,
    language: String,
}

impl Transcriber {
    pub fn new(config: &Config) -> Result<Self> {
        let ctx = WhisperContext::new_with_params(
            config.model_path.to_str().context("Invalid model path")?,
            WhisperContextParameters::default(),
        )
        .context("Failed to load Whisper model")?;

        Ok(Self {
            ctx,
            language: config.language.clone(),
        })
    }

    /// Transcribe a 16kHz mono f32 PCM buffer.
    /// Returns Some(text) if speech was detected, None otherwise.
    pub fn transcribe(&mut self, samples: &[f32]) -> Result<Option<String>> {
        if samples.is_empty() {
            return Ok(None);
        }

        let mut params = FullParams::new(SamplingStrategy::Greedy { best_of: 1 });

        // Language
        if self.language == "auto" {
            params.set_language(None);
        } else {
            params.set_language(Some(&self.language));
        }

        // Performance settings
        params.set_n_threads(num_cpus());
        params.set_print_special(false);
        params.set_print_progress(false);
        params.set_print_realtime(false);
        params.set_print_timestamps(false);
        params.set_single_segment(false);
        params.set_no_context(true); // Don't use context from previous segments
        params.set_suppress_blank(true);

        // Token timestamps for filtering
        params.set_token_timestamps(false);

        let mut state = self.ctx.create_state().context("Failed to create Whisper state")?;

        state
            .full(params, samples)
            .context("Whisper inference failed")?;

        let n_segments = state.full_n_segments()?;
        debug!("Whisper produced {} segments", n_segments);

        if n_segments == 0 {
            return Ok(None);
        }

        let mut result = String::new();
        for i in 0..n_segments {
            let seg = state.full_get_segment_text(i).context("Failed to get segment text")?;
            let seg = seg.trim();

            // Filter out common hallucinations / noise markers
            if is_hallucination(seg) {
                debug!("Filtered hallucination: {:?}", seg);
                continue;
            }

            if !result.is_empty() {
                result.push(' ');
            }
            result.push_str(seg);
        }

        if result.is_empty() {
            Ok(None)
        } else {
            Ok(Some(result))
        }
    }
}

/// Whisper sometimes hallucinates these patterns on silence/noise
fn is_hallucination(text: &str) -> bool {
    let lower = text.to_lowercase();
    let hallucinations = [
        "[musik]", "[music]", "(musik)", "(music)",
        "[laughter]", "[applause]", "[silence]",
        "[ musik ]", "[ music ]",
        "vielen dank", "danke schön", "thank you for watching",
        "untertitel", "subtitles", "www.", ".com",
        "♪", "♫",
    ];
    hallucinations.iter().any(|h| lower.contains(h))
        || lower.chars().all(|c| c == '.' || c == ' ' || c == '\n')
}

fn num_cpus() -> i32 {
    std::thread::available_parallelism()
        .map(|n| n.get() as i32)
        .unwrap_or(4)
        .min(8) // Whisper benefits from up to ~8 threads
}
